package com.steps;

import com.main_java.compare_main;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class compare 
{
	compare_main cm = new  compare_main();

	@Given("^open the site$")
	public void log() 
	{
		cm.opening() ;
	}

	@When("^compare price of 2 products$")
	public void comparison()
	{
		cm.compare();
	}
}
