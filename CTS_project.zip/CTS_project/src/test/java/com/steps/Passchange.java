package com.steps;

import com.main_java.Pass_change;
import com.main_java.giftcertificates;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class Passchange 
{
	 Pass_change pc = new   Pass_change();

		@Given("^go into site$")
		public void logedin() 
		{
			
			pc.login_with_old_pass();
		}

		@When("^change pass$")
		public void wishes()
		{
			
			pc.confirm_pass();
		}
}
