package com.steps;

import com.main_java.Wishlist_main;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class Wishlist 
{	
		 Wishlist_main wi = new  Wishlist_main();

		@Given("^the user logged in$")
		public void logedin() 
		{
			
			wi.loginpass() ;
		}

		@When("^add items to wishlist$")
		public void wishes()
		{
			
			wi.wish();
		}
}


