package com.steps;

import com.main_java.Special_main;
import com.main_java.Wishlist_main;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class special {
	 Special_main sp = new  Special_main();

		@Given("^click specials$")
		public void logedin() 
		{
			
			sp.open_special() ;
		}

		@When("^display special offers$")
		public void wishes()
		{
			
			sp.offers();
		}
}
