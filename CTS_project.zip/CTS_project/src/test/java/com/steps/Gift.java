package com.steps;


import com.main_java.giftcertificates;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class Gift {
	 giftcertificates gc = new  giftcertificates();

		@Given("^logged in to enter recipient details$")
		public void logedin() 
		{
			
			gc.login_pass() ;
		}

		@When("^enter recipient details$")
		public void wishes()
		{
			
			gc.recipient();
		}
}
