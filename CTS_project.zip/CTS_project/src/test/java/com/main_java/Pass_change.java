package com.main_java;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Pass_change {
WebDriver driver;
	

	public void login_with_old_pass() 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\BLTuser.BLT1226\\Desktop\\sound works\\drive\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driver.get("https://demo.opencart.com/");
		driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a/i")).click();
		driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[2]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"input-email\"]")).sendKeys("soundaryariya27@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"input-password\"]")).sendKeys("sound");
		driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[2]/div/form/input")).click();
		
	}

	public void confirm_pass() 
	{
		driver.findElement(By.xpath("//*[@id=\"column-right\"]/div/a[3]")).click();
		driver.findElement(By.name("password")).sendKeys("sound");
		driver.findElement(By.name("confirm")).sendKeys("sound");
		driver.findElement(By.xpath("//*[@id=\"content\"]/form/div/div[2]/input")).click();
	}
	
}
